# クラスターの可視化

## 依存パッケージのインストール

```bash
pip install -r requirements.txt
```

## 実行方法

1. 可視化したいマップの`gml`ファイルを`main.py`と同じディレクトリに置く(`rcrs-server/map/*/map/map.gml`です)
2. 可視化したいクラスターの出力結果を`clusters = []`に追加する
3. `main.py`を実行する
