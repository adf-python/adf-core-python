import matplotlib.colors as mcolors
import matplotlib.pyplot as plt
from lxml import etree
from matplotlib import colormaps

# GMLファイルをバイト形式で読み込む
with open("./map.gml", "rb") as file:
    gml_data = file.read()

# GMLデータを解析する
root = etree.fromstring(gml_data)

clusters = [
    [
        257,
        259,
        262,
        263,
        270,
        278,
        280,
        297,
        336,
        913,
        914,
        915,
        916,
        917,
        918,
        919,
        933,
        941,
        942,
        943,
        944,
        945,
        946,
        947,
        974,
        250,
        253,
    ],
    [349, 896, 899, 902, 934, 960, 968, 969, 970, 971, 248, 251],
    [
        258,
        266,
        268,
        269,
        274,
        275,
        279,
        920,
        921,
        922,
        923,
        924,
        925,
        926,
        927,
        928,
        929,
        932,
        948,
        949,
        950,
        951,
        952,
        953,
        954,
        955,
        956,
        957,
        958,
        959,
        975,
        976,
        254,
        255,
    ],
    [
        256,
        271,
        273,
        281,
        296,
        298,
        314,
        330,
        903,
        904,
        905,
        910,
        911,
        912,
        935,
        936,
        937,
        938,
        939,
        940,
        247,
        249,
    ],
]

GML_NAMESPACE = "{http://www.opengis.net/gml}"
XLINK_NAMESPACE = "{http://www.w3.org/1999/xlink}"
ROBORESCUE_NAMESPACE = "{urn:roborescue:map:gml}"

n = len(clusters)
colors = [mcolors.rgb2hex(colormaps.get_cmap("tab20")(i)) for i in range(n)]

entity_to_color_dict = {}
for i, cluster in enumerate(clusters):
    for entity in cluster:
        entity_to_color_dict[entity] = i

# ノード、エッジ、建物、道路の情報を取得
nodes = root.findall(f".//{GML_NAMESPACE}Node")
edges = root.findall(f".//{GML_NAMESPACE}Edge")
buildings = root.findall(f".//{ROBORESCUE_NAMESPACE}building")
roads = root.findall(f".//{ROBORESCUE_NAMESPACE}road")

# ノード、エッジ、建物、道路の情報を辞書形式に変換
nodes_dict = {}
for node in nodes:
    id = node.attrib[f"{GML_NAMESPACE}id"]
    point = node.find(f".//{GML_NAMESPACE}coordinates").text
    nodes_dict[id] = point.split(",")

edges_dict = {}
for edge in edges:
    id = edge.attrib[f"{GML_NAMESPACE}id"]
    directed_nodes = edge.findall(f".//{GML_NAMESPACE}directedNode")
    directed_nodes_id = [
        directed_node.attrib[f"{XLINK_NAMESPACE}href"].replace("#", "")
        for directed_node in directed_nodes
    ]
    edges_dict[id] = directed_nodes_id

buildings_geom_dict = {}
for building in buildings:
    building_id = building.attrib[f"{GML_NAMESPACE}id"]
    faces = building.findall(f".//{GML_NAMESPACE}Face")
    building_edges = []
    for face in faces:
        directed_edges = face.findall(f".//{GML_NAMESPACE}directedEdge")
        for directed_edge in directed_edges:
            edge_id = directed_edge.attrib[f"{XLINK_NAMESPACE}href"].replace("#", "")
            building_edges.append(edge_id)
    buildings_geom_dict[building_id] = building_edges

roads_geom_dict = {}
for road in roads:
    road_id = road.attrib[f"{GML_NAMESPACE}id"]
    faces = road.findall(f".//{GML_NAMESPACE}Face")
    road_edges = []
    for face in faces:
        directed_edges = face.findall(f".//{GML_NAMESPACE}directedEdge")
        for directed_edge in directed_edges:
            edge_id = directed_edge.attrib[f"{XLINK_NAMESPACE}href"].replace("#", "")
            road_edges.append(edge_id)
    roads_geom_dict[road_id] = road_edges

geometries = {**buildings_geom_dict, **roads_geom_dict}

for geometry_id, geometry in geometries.items():
    color = entity_to_color_dict[int(geometry_id)]
    for edge_id in geometry:
        if edge_id in edges_dict:
            node_ids = edges_dict[edge_id]
            x_coords = [float(nodes_dict[node_id][0]) for node_id in node_ids]
            y_coords = [float(nodes_dict[node_id][1]) for node_id in node_ids]
            plt.plot(x_coords, y_coords, color=colors[color])

plt.xlabel("x")
plt.ylabel("y")
plt.show()
